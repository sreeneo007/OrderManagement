﻿
using OrderManagement.DAL;
using OrderManagement.Services.Implementations;
using OrderManagement.Services.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;

namespace OrderManagement
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

       
        public void ConfigureServices(IServiceCollection services)
        {
        
            services.AddDbContext<OrderManagementDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("BankAccountManagementConnection")));           
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddSwaggerGen(x =>
                {
                    x.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                    {
                        Title = "Order Management API",
                        Version = "v2",
                        Contact = new Microsoft.OpenApi.Models.OpenApiContact
                        {
                            Name = "Sreenath Sreedhar",
                            Email = "sreeneo007@gmail.com"

                        }

                    });

                });


            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();             

            }
            app.UseHttpsRedirection();

            app.UseRouting();   

            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(x => {

                var prefix = string.IsNullOrEmpty(x.RoutePrefix) ? "." : "..";
                x.SwaggerEndpoint($"{prefix}/swagger/v2/swagger.json", "Order Mangement API");

            });

            app.UseEndpoints(endpoints => endpoints.MapControllers());

        }
    }
}
