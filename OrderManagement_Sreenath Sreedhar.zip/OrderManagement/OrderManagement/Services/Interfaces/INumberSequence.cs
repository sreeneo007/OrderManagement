﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagement.Services.Interfaces
{
    public interface INumberSequence
    {
        string GetNumberSequence(string module);
    }
}
