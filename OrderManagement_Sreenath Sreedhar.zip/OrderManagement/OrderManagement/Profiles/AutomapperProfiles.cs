﻿using AutoMapper;
using OrderManagement.Models;
using System.Transactions;

namespace OrderManagement.Profiles
{
    public class AutomapperProfiles:Profile
    {

        public AutomapperProfiles()
        {

           // Auto Mapper Code to Map Models

        }
    }
}
