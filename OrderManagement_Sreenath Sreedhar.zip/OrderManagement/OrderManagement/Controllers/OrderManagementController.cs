﻿using AutoMapper;
using OrderManagement.Models;
using OrderManagement.Services.Implementations;
using OrderManagement.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Security.Principal;
using System.Text.RegularExpressions;
using OrderManagement.DAL;
using Microsoft.EntityFrameworkCore;
using OrderManagement.Models.SyncfusionViewModels;
using Microsoft.AspNetCore.Authorization;

namespace OrderManagement.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/OrderLine")]
    public class OrderManagementController : ControllerBase
    {

        private readonly OrderManagementDbContext _context;
        private readonly INumberSequence _numberSequence;

        public OrderManagementController(OrderManagementDbContext context,
                       INumberSequence numberSequence)
        {
            _context = context;
            _numberSequence = numberSequence;
        }

        // GET: api/PurchaseOrder
        [HttpGet]
        public async Task<IActionResult> GetPurchaseOrder()
        {
            List<PurchaseOrder> Items = await _context.PurchaseOrder.ToListAsync();
            int Count = Items.Count();
            return Ok(new { Items, Count });
        }


        [HttpGet("[action]/{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            PurchaseOrder result = await _context.PurchaseOrder
                .Where(x => x.PurchaseOrderId.Equals(id))
                .Include(x => x.PurchaseOrderLines)
                .FirstOrDefaultAsync();
            return Ok(result);
        }



        [HttpPost("[action]")]
        public IActionResult AddOrder([FromBody] CrudViewModel<PurchaseOrder> payload)
        {
            PurchaseOrder purchaseOrder = payload.value;
            purchaseOrder.PurchaseOrderName = _numberSequence.GetNumberSequence("PO");
            _context.PurchaseOrder.Add(purchaseOrder);
            _context.SaveChanges();
            this.UpdatePurchaseOrder(purchaseOrder.PurchaseOrderId);
            return Ok(purchaseOrder);
        }


        [HttpPost("[action]")]
        public IActionResult UpdateOrder([FromBody] CrudViewModel<PurchaseOrder> payload)
        {
            PurchaseOrder purchaseOrder = payload.value;
            _context.PurchaseOrder.Update(purchaseOrder);
            _context.SaveChanges();
            this.UpdatePurchaseOrder(purchaseOrder.PurchaseOrderId);
            return Ok(purchaseOrder);
        }

        [HttpPost("[action]")]
        public IActionResult RemoveOrder([FromBody] CrudViewModel<PurchaseOrder> payload)
        {
            PurchaseOrder purchaseOrder = _context.PurchaseOrder
                .Where(x => x.PurchaseOrderId == (int)payload.key)
                .FirstOrDefault();
            _context.PurchaseOrder.Remove(purchaseOrder);
            _context.SaveChanges();
            this.UpdatePurchaseOrder(purchaseOrder.PurchaseOrderId);
            return Ok(purchaseOrder);
        }


        private void UpdatePurchaseOrder(int purchaseOrderId)
        {
            try
            {
                PurchaseOrder purchaseOrder = new PurchaseOrder();
                purchaseOrder = _context.PurchaseOrder
                    .Where(x => x.PurchaseOrderId.Equals(purchaseOrderId))
                    .FirstOrDefault();

                if (purchaseOrder != null)
                {
                    List<PurchaseOrderLine> lines = new List<PurchaseOrderLine>();
                    lines = _context.PurchaseOrderLine.Where(x => x.PurchaseOrderId.Equals(purchaseOrderId)).ToList();

                    //update master data by its lines
                    purchaseOrder.Amount = lines.Sum(x => x.Amount);
                    purchaseOrder.SubTotal = lines.Sum(x => x.SubTotal);

                    purchaseOrder.Discount = lines.Sum(x => x.DiscountAmount);
                    purchaseOrder.Tax = lines.Sum(x => x.TaxAmount);

                    purchaseOrder.Total = purchaseOrder.Freight + lines.Sum(x => x.Total);

                    _context.Update(purchaseOrder);

                    _context.SaveChanges();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
