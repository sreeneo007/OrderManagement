using OrderManagement.DAL;
using OrderManagement.Services.Implementations;
using OrderManagement.Services.Interfaces;
using Microsoft.AspNetCore;
using Microsoft.EntityFrameworkCore;
using System.Numerics;


namespace OrderManagement
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }

}