﻿using OrderManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace OrderManagement.DAL
{
    public class OrderManagementDbContext:DbContext
    {
        public OrderManagementDbContext(DbContextOptions<OrderManagementDbContext> options):base (options)
        {
        
        
        }

        //Db sets 
        public DbSet<Product> Product { get; set; }

        public DbSet<ProductType> ProductType { get; set; }

        public DbSet<PurchaseOrder> PurchaseOrder { get; set; }

        public DbSet<PurchaseOrderLine> PurchaseOrderLine { get; set; }

        public DbSet<PurchaseType> PurchaseType { get; set; }

        public DbSet<NumberSequence> NumberSequence { get; set; }


    }
}
