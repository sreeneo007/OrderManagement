﻿namespace OrderManagement.Utilities
{
    public class AppSettings
    {


    }
}
